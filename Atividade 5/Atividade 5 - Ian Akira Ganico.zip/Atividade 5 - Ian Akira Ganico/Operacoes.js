var Val1 = parseFloat(prompt("Qual é o valor do Val1 ?"));
var Val2 = parseFloat(prompt("Qual é o valor do Val2 ?"));

Soma = (Val1 + Val2);
Subt = (Val1 - Val2);
Prod = (Val1 * Val2);
Divs = (Val1 / Val2);
Rest = (Val1 % Val2);

alert("\n Valor 1 = " + Val1 +
      "\n Valor 2 = " + Val2 +
	  "\n Soma dos Valores = " + Soma +
      "\n Subtracao dos Valores = " + Subt +
	  "\n Produto dos Valores = " + Prod +
	  "\n Divisao dos Valores = " + Divs +
	  "\n Resto da Divisao dos Valores = " + Rest)