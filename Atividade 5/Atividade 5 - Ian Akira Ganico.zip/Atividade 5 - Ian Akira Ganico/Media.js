var Nota1 = parseFloat(prompt("Qual é a sua nota 1?"));
var Nota2 = parseFloat(prompt("Qual é a sua nota 2?"));
var Trabalho = parseFloat(prompt("Qual é a sua nota de Trabalho ?"));

Media = ((Nota1 + Nota2 + Trabalho) / 3);

alert("\n Nota 1 = " + Nota1 +
      "\n Nota 2 = " + Nota2 +
	  "\n Trabalho = " + Trabalho +
      "\n Nota final = " + Media)